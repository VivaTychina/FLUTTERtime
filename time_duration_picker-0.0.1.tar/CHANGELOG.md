## 0.0.1

* Support for hot reloaded is added when values get updated. The enviroment sdk is also updated.

## 0.0.1-dev.5

* The diameter for the TimeDurationPicker is now checked against parent constraints.

## 0.0.1-dev.4

* The gif was not showing in the pub.dev readme.

## 0.0.1-dev.3

* Added doc file and sample gif.

